import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  private baseUrl = 'http://20.244.144.173:8000/api';
  private langSource = new BehaviorSubject<string>('en');
  currentLang$ = this.langSource.asObservable();

 
  constructor(private http: HttpClient) {}


  setLanguage(lang: string) {
    this.langSource.next(lang);
  }
  getFeaturedNews(langCode: any): Observable<any> {
    console.log("langSource",this.langSource)
    return this.http.get(`${this.baseUrl}/featured-news?lang=${langCode }`);
  }

  getBulletinNews(): Observable<any> {
    return this.http.get(`${this.baseUrl}/alerts`);
  }

  getTrendingNews(): Observable<any> {
    return this.http.get(`${this.baseUrl}/trending-news`);
  }

  getGlobalNews(): Observable<any> {
    return this.http.get(`${this.baseUrl}/around-the-globe`);
  }

  getKnowledgeHub(): Observable<any> {
    return this.http.get(`${this.baseUrl}/knowledge-hub`);
  }

  getCategoryDetails(category: string): Observable<any> {
    const encodedCategory = encodeURIComponent(category);
    return this.http.get(`${this.baseUrl}/search?keyword=${encodedCategory}&threshold=70`);
}
}
